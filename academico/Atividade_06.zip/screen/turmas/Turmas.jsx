import React from 'react'
import { Text } from 'react-native'

const Turmas = ({navigation}) => {
  return (
    <Text>Turmas</Text>
  )
}

export default Turmas