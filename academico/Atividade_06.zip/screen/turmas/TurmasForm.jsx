import React from 'react'
import { Text } from 'react-native'

const TurmasForm = () => {
  return (
    <Text>TurmasForm</Text>
  )
}

export default TurmasForm